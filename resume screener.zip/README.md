# Resumind
A C++-based resume screener that extracts candidate data, compresses resume text using Huffman Coding, and ranks candidates based on job relevance.
